 // Imprimir mensajes
console.log('Hola Gente Como Estan')

//Declarar variables
var saludar = 'Hola'
var quien = 'mundo'

console.log = ("%s, %s", saludar, quien)

//imprimir objetos
console.log({
    'Nombre': 'Brandon',
    'Horario': '15:00 - 22:30',
    'Salón': 'Laboratorio de Redes'
})


