

export default function Card(nombre, carrera, semestre){
    const tarjetas = document.createElement('div')
    tarjetas.innerHTML = 
    `<p>${nombre}</p>
     <p>${carrera}</p>
     <p>${semestre}</p>
    `
}