export default function Header({titulo}){
    const header = document.createElement('header')
    //Diferencia entre innertext y innerHTML
    header.innerHTML = `<h1>${titulo}</h1>`
    return header
}







