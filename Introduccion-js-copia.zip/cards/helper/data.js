const personas = [
    {
        nombre: 'Brandon',
        carrera: 'Ing. Sistemas Computacionales',
        semestre: 7,
        image: {

        }
    },

]