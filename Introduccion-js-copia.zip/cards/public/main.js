import './style.css'

import Header from '../components/header'
import Card from '../components/Card'

const empresa = {
    titulo: 'Manejo de Sistemas Agrarios',
    giro: 'Agricultura'
}

document.body.appendChild(Header(empresa))

personas.forEach((personas) => {
    document.body.appendChild(Card(personas))
})

