//Tipos de datos
var enteros = 90 // 32 bits - Int :: -2,147,483,648 al 2,147,483,648
var long = 843488459345 // 64 bits :: long -9,223,372,036,
var flotante = 5.3 //32 bits
var double = 3432483247324823642.34 //64 bits

console.log(long)

var booleano = true
var booleano2 = false
console.log(typeof booleano, typeof booleano2)

//Ejemplo de NAN
var nan_ejemplo = 0/0
console.log(nan_ejemplo)

var not_a_number = NaN
console.log(typeof not_a_number)

var notDefine
console.log(typeof notDefine)

//String 
var string = 1; var string2 = 2
console.log(string + string2)

