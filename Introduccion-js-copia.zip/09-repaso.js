//variables
const variable = ''
console.log(typeof variable)
/** Tipos de datos
 * number
 * string
 * boolean
 * arrays
 * objetos
 */

const frutas = ['🍎', '🍐', '🍇', '🍉', '🍒']
/**
 * 
 * for(let i = 0; i < arreglo.length; i++){
    console.log(arreglo[i])
 */

//El for ofegresa el contenido que existe en el arreglo r
//El for in regresa el INDICE que existe en el arreglo.
//La funcion "map " es capaz de recibir tres parámetros: 1ro item, 2do index, 3ro 


//----------------------------------------------------

//frutas.map(fruta=>{
  //  console.log(fruta)
//})


//Ventajas de function map:
/**
 * Regresa valores
 * 
 * 
 * 
 * 
 * 
 * 
 * Spread operator.
 */
