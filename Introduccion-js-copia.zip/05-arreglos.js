/**Arreglos */
var frutasFavoritas = ["mango", "plátano", 'uva']
console.log(frutasFavoritas)

var loteCarros = ["toyota", "lexus", "mazda", "nissan"]
var estudiantes = ["Jorge", "Brandon", "Elian", "valenzuela"]
var calificaciones = [9.5, 3.4, 5.6, 6.7]
var variablesRamdon = ["Nube", 3.2, null, true, false]

console.log(loteCarros)
console.log(estudiantes)
console.log(calificaciones)
console.log(variablesRamdon)

//index
console.log(loteCarros[1])